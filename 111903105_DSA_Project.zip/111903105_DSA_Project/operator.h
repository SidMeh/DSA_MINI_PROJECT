
typedef struct opt_stack{
    char *a;
    int size;
    int top;
}opt_stack;

void opt_init(opt_stack *s, int len);
void opt_push(opt_stack *s, char op);
int isFull(opt_stack s) ;
int opt_empty(opt_stack s);
char opt_pop(opt_stack *s);
char opt_top(opt_stack s);
