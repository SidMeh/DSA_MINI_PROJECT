#define START 10 
#define DIGIT 20
#define OPERATOR 30
#define ERROR 40
#define STOP 50
#define SPACEN 60
#define SPACEP 70
//#include "Number2.h"

typedef struct token{
 int type;
}token;

void evaluate(char *ch);
int precedence(char op);
void applyop(char op);
