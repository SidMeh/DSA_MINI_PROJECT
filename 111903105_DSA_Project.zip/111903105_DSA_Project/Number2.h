
typedef struct node{
	int data;
//	int sign;
	struct node* prev;
	struct node* next;
}node;

typedef node* list;




typedef struct stack{
	int top;
//	int size;
	int sign[100];
	list l[100];
}stack; 


void init(list *l) ;
void append(list *l, int d);
void insert_beg(list *l,int d);
int len(list l);
void init_opd(stack *s);
void push_opd(stack *s,char *ptr);
void pop_opd(stack *s);
void add(stack *s);
int subtract(stack *s);
void multiply(stack *s);
void delete(list *l);
void traverse_fwd(list l);
void pop_once(list *l,int d);
void divide(stack *s);
void mod(stack *s);
int iszero(list s);
void power(stack *s);
int get(stack *s);

